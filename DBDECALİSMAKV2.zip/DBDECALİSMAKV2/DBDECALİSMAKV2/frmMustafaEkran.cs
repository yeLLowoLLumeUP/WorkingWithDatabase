﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBDECALİSMAKV2
{
    public partial class frmMustafaEkran : Form
    {
        private bool filterApplied = false;
        bool tiklandiMi = false;
        public frmMustafaEkran()
        {
            InitializeComponent();
        }

        private void RefreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // re-read data
            this.productsTableAdapter.Fill(this.northWindDataSet.Products);
            UpdateStatusLabels();
            // ensure binding navigator is enabled and bound
            try { this.bindingNavigator1.BindingSource = this.productsBindingSource; this.bindingNavigator1.Enabled = true; } catch { }
        }

        private void ToggleGridlinesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // toggle gridline visibility
            this.productsDataGridView.CellBorderStyle = this.productsDataGridView.CellBorderStyle == DataGridViewCellBorderStyle.None ? DataGridViewCellBorderStyle.Single : DataGridViewCellBorderStyle.None;
        }

        private void ExportCsvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "CSV files|*.csv|All files|*.*";
                if (sfd.ShowDialog(this) == DialogResult.OK)
                {
                    var sb = new StringBuilder();
                    var cols = productsDataGridView.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).ToList();
                    sb.AppendLine(string.Join(",", cols.Select(c => "\"" + c.HeaderText.Replace("\"", "\"\"") + "\"")));
                    foreach (DataGridViewRow row in productsDataGridView.Rows)
                    {
                        if (row.IsNewRow) continue;
                        var vals = new List<string>();
                        foreach (var c in cols)
                        {
                            var v = row.Cells[c.Index].Value?.ToString() ?? string.Empty;
                            vals.Add("\"" + v.Replace("\"", "\"\"") + "\"");
                        }
                        sb.AppendLine(string.Join(",", vals));
                    }
                    System.IO.File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                    MessageBox.Show("CSV dışa aktarıldı.");
                }
            }
        }

        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ürünler uygulaması\nSürüm 1.0", "About");
        }

        private void NotifyRestoreMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            this.Show();
            this.BringToFront();
        }

        private void frmMustafaEkran_Load(object sender, EventArgs e)
        {
            // Fill dataset
            this.productsTableAdapter.Fill(this.northWindDataSet.Products);
            // ensure case-insensitive filtering
            this.northWindDataSet.CaseSensitive = false;
            // populate filter column list
            toolStripComboBox1.Items.Clear();
            toolStripComboBox1.Items.AddRange(new string[] {
                "ProductName","SupplierID","CategoryID","UnitsInStock","UnitPrice","Discontinued"
            });
            toolStripComboBox1.SelectedIndexChanged += ToolStripComboBox1_SelectedIndexChanged;

            UpdateStatusLabels();
        }

        private void ToolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // populate values for selected column (distinct)
            toolStripComboBox2.Items.Clear();
            var col = toolStripComboBox1.Text;
            if (string.IsNullOrWhiteSpace(col)) return;
            var values = new HashSet<string>();
            foreach (DataRow r in northWindDataSet.Products.Rows)
            {
                if (!r.IsNull(col)) values.Add(r[col].ToString());
            }
            toolStripComboBox2.Items.AddRange(values.ToArray());
        }

        private void UpdateStatusLabels()
        {
            try
            {
                int rows = this.productsBindingSource.Count;
                int totalStock = 0;
                foreach (DataRowView drv in this.productsBindingSource)
                {
                    if (drv.Row.Table.Columns.Contains("UnitsInStock") && !drv.Row.IsNull("UnitsInStock"))
                    {
                        totalStock += Convert.ToInt32(drv.Row["UnitsInStock"]);
                    }
                }
                toolStripTotalLabel.Text = $"Toplam Stok: {totalStock}";
                toolStripStatus.Text = $"Toplam Satır Sayısı: {rows}";
            }
            catch
            {
                // ignore
            }
        }

        private void yazdirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoPrint();
        }

        private void toolStripButtonPrint_Click(object sender, EventArgs e)
        {
            DoPrint();
        }

        private void DoPrint()
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Simple print: render the DataGridView as text (basic)
            int y = e.MarginBounds.Top;
            var font = new Font("Arial", 10);
            for (int r = 0; r < productsDataGridView.Rows.Count; r++)
            {
                string line = "";
                for (int c = 0; c < productsDataGridView.Columns.Count; c++)
                {
                    var cell = productsDataGridView.Rows[r].Cells[c].FormattedValue?.ToString() ?? "";
                    line += cell + "\t";
                }
                e.Graphics.DrawString(line, font, Brushes.Black, e.MarginBounds.Left, y);
                y += (int)font.GetHeight(e.Graphics) + 2;
                if (y > e.MarginBounds.Bottom) { break; }
            }
        }

        private void cikisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dr = MessageBox.Show("Çıkmak istiyor musunuz?", "Çıkış", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes) this.Close();
        }

        private void toolStripButtonFilter_Click(object sender, EventArgs e)
        {
            var button = (sender as ToolStripButton);

            tiklandiMi = !tiklandiMi;
            if (!tiklandiMi)
            {
                toolStripButtonFilter.Text = "Filtrele";
                northWindDataSet.Products.DefaultView.RowFilter = null;
                return;
            }

            button.Text = "Tümünü Göster";

            string sutunBilgisi = toolStripComboBox1.Text;
            string filtreIcerik = toolStripComboBox2.Text;

            try
            {
                northWindDataSet.Products.DefaultView.RowFilter = $"{sutunBilgisi} LIKE '%{filtreIcerik}%'";
            }
            catch (Exception)
            {
                MessageBox.Show("Tip Uyuşmazlığı");
            }
            finally
            {
                productsDataGridView.DataSource = northWindDataSet.Products.DefaultView;
            }
        }

        private void toolStripButtonShowAll_Click(object sender, EventArgs e)
        {
            // Clear filters and refresh
            productsBindingSource.RemoveFilter();
            UpdateStatusLabels();
        }

        private void bindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.productsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.northWindDataSet);
                MessageBox.Show("Kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kaydetme sırasında hata: " + ex.Message);
            }
        }

        private void toolStripButtonChart_Click(object sender, EventArgs e)
        {
            // Improved chart: scrollable + animated bars + better label handling
            var rows = northWindDataSet.Products.Rows.Cast<DataRow>().ToList();
            int height = 600;
            int margin = 60;
            int spacing = 8;
            int preferredBarWidth = 48; // wider bars for readability

            var values = new List<int>();
            var names = new List<string>();
            int max = 0;
            foreach (DataRow r in rows)
            {
                int v = 0; if (!r.IsNull("UnitsInStock")) int.TryParse(r["UnitsInStock"].ToString(), out v);
                values.Add(v);
                var nm = (r["ProductName"]?.ToString() ?? "").Trim();
                names.Add(nm);
                if (v > max) max = v;
            }
            if (max == 0) max = 1;

            int count = Math.Max(1, values.Count);
            int chartW = count * (preferredBarWidth + spacing) + margin * 2;
            // ensure minimum visible width
            chartW = Math.Max(chartW, 900);

            var frm = new Form();
            frm.Text = "Stok Grafiği";
            frm.Width = Math.Min(1400, chartW + 40);
            frm.Height = height;

            var panel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.White };
            var pic = new PictureBox { Location = new Point(0, 0), BackColor = Color.White };
            pic.Size = new Size(chartW, height);
            panel.Controls.Add(pic);
            frm.Controls.Add(panel);

            // create a timer to animate bars
            var timer = new Timer { Interval = 20 };
            double progress = 0.0; // 0..1

            void DrawFrame(double p)
            {
                var bmp = new Bitmap(pic.Width, pic.Height);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    g.Clear(Color.White);
                    int chartH = pic.Height - margin * 2;

                    // axis line
                    g.DrawLine(Pens.Gray, margin / 2, margin + chartH, pic.Width - margin / 2, margin + chartH);

                    for (int i = 0; i < count; i++)
                    {
                        int barW = preferredBarWidth;
                        int x = margin + i * (barW + spacing);
                        int targetBarH = (int)((values[i] / (double)max) * (chartH - 30));
                        int barH = (int)(targetBarH * p);
                        int y = margin + (chartH - barH);

                        var rect = new Rectangle(x, y, barW, barH);
                        using (var brush = new SolidBrush(Color.FromArgb(200, 70, 130, 180)))
                        {
                            g.FillRectangle(brush, rect);
                        }
                        g.DrawRectangle(Pens.DimGray, rect);

                        // label handling: abbreviate if too long
                        string label = names[i];
                        var font = SystemFonts.DefaultFont;
                        var fm = g.MeasureString(label, font);
                        if (fm.Width > barW + 6)
                        {
                            // rotated label for long names
                            g.TranslateTransform(x + barW / 2f, margin + chartH + 6);
                            g.RotateTransform(-45);
                            var clipped = label.Length > 40 ? label.Substring(0, 37) + "..." : label;
                            g.DrawString(clipped, font, Brushes.Black, -g.MeasureString(clipped, font).Width / 2f, 0);
                            g.ResetTransform();
                        }
                        else
                        {
                            g.DrawString(label, font, Brushes.Black, x, margin + chartH + 6);
                        }
                    }
                }
                // swap image on UI thread
                var old = pic.Image;
                pic.Image = bmp;
                old?.Dispose();
            }

            timer.Tick += (s, ea) =>
            {
                progress += 0.04; // speed
                if (progress > 1.0) progress = 1.0;
                DrawFrame(progress);
                if (progress >= 1.0)
                {
                    timer.Stop();
                }
            };

            // initial frame (empty) then start animation
            DrawFrame(0.0);
            timer.Start();

            // show form modally
            frm.ShowDialog(this);
        }
    }
}
